import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.firefox.FirefoxDriver; 
import org.junit.BeforeClass;
import org.openqa.selenium.By; 

public class NewHotel 

	{
	
		private WebDriver driver;

		public void Startup() throws InterruptedException
	{
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		
	}
	
		public void Bookings() throws Exception
		
	{
	    driver.get("http://52.50.87.129:3001/");      
	    driver.findElement(By.id("firstname")).sendKeys("Fname");
	    driver.findElement(By.id("lastname")).sendKeys("Lname");
	    driver.findElement(By.id("totalprice")).sendKeys("200.00");
	    driver.findElement(By.id("depositpaid")).sendKeys("true");
	    driver.findElement(By.id("checkin")).sendKeys("2016-08-18");
	    driver.findElement(By.id("checkout")).sendKeys("2016-08-19");
	    driver.findElement(By.cssSelector("#form > div.row > div.col-md-1 > input[type=\"button\"]")).click();
	   

	}
	
		public void delete()
	
			{
	    		driver.findElement(By.cssSelector("#bookings > div.row > div.col-md-1 > input[type=\"button\"]")).click();	    	
			}
		
		public void quit()
			{
				driver.quit();
			}
		
		public static void main(String[]args) throws Exception
	
			{
		
				NewHotel a = new NewHotel();
				a.Startup();	
				a.Bookings();
				System.out.println("First records have been successfully inserted!");
				Thread.sleep(2000);
				a.delete();
				System.out.println("First records have been successfully deleted!");
				Thread.sleep(2000);
			
			for(int i=0; i<=3;i++)
				
				{
					a.Bookings();	
				}
				
				a.quit();
		
			System.out.println("Multiple records have been successfully inserted!");			
			
		}
	
}