
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.firefox.FirefoxDriver; 
import org.junit.Test;  
import org.openqa.selenium.By; 
import org.openqa.selenium.WebElement; 
import org.openqa.selenium.Keys;
import java.util.ArrayList;

public class HotelBooking 
{ 

        /** 
         * @param args 
         */ 
        public static void main(String[] args) { 
                // TODO Auto-generated method stub 
                WebDriver driver = new FirefoxDriver();
                //To Maximize Browser Window
                driver.manage().window().maximize();
                driver.get("http://10.105.175.29:8089/"); 

                
                driver.findElement(By.id("firstname")).sendKeys("Fname");
            	driver.findElement(By.id("lastname")).sendKeys("Lname");
            	driver.findElement(By.id("totalprice")).sendKeys("200.00");
            	driver.findElement(By.id("depositpaid")).sendKeys("true");
            	driver.findElement(By.id("checkin")).sendKeys("2016-08-18");
            	driver.findElement(By.id("checkout")).sendKeys("2016-08-19");
            	//driver.findElement(By.xpath("/html/body/div/div[3]/div/div[7]")).click(); 
            	driver.findElement(By.cssSelector("#form > div.row > div.col-md-1 > input[type=\"button\"]")).click();
            	driver.findElement(By.cssSelector("#bookings > div.row > div.col-md-1 > input[type=\"button\"]")).click();
       
            	driver.close();
         }
}
       /* public class Array {

       	 public void main(String[] args) {
       		//ArrayList<String> Records = new ArrayList<String>();
       		//Now you can store any number of values In this arraylist as bellow. Size constrain will comes never.
             WebDriver driver = new FirefoxDriver();
             //To Maximize Browser Window
             driver.manage().window().maximize();
             driver.get("http://10.105.175.29:8089/");
       		String str[][] = new String[4][6]; //4 rows, 6 columns
       		str[0][0]=driver.findElement(By.id("firstname")).sendKeys("NameOne");
       		str[1][0]=driver.findElement(By.id("lastname")).sendKeys("Lname");
}
*/
